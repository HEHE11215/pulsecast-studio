import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Dedicated isolated browser profile
export const USER_DATA_DIR = path.join(__dirname, '..', 'storage', 'browser_profile');

if (!fs.existsSync(USER_DATA_DIR)) {
  fs.mkdirSync(USER_DATA_DIR, { recursive: true });
}

export function hasSession() {
  const defaultDir = path.join(USER_DATA_DIR, 'Default');
  return fs.existsSync(defaultDir) || fs.existsSync(USER_DATA_DIR);
}

/**
 * Launches an isolated persistent Chromium browser context.
 * Uses Playwright's built-in Chromium (no lock collision with running Google Chrome).
 */
export async function createPersistentContext(headless = false) {
  const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
    headless: headless,
    viewport: { width: 1280, height: 720 },
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    args: [
      '--disable-blink-features=AutomationControlled',
      '--no-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--no-first-run'
    ]
  });

  return context;
}
