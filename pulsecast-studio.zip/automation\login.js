import { createPersistentContext } from './browser.js';

async function loginInteractive() {
  console.log('Launching dedicated persistent Chrome instance for YouTube Studio sign-in...');
  console.log('Please log into your Google/YouTube account in the browser window.');
  console.log('Once you are inside YouTube Studio, you can close the browser window.');

  const context = await createPersistentContext(false);
  const page = context.pages().length > 0 ? context.pages()[0] : await context.newPage();

  await page.goto('https://studio.youtube.com');

  // Keep it open while the user logs in until YouTube Studio is reached
  console.log('Waiting for YouTube Studio navigation (or until you complete login)...');
  try {
    await page.waitForURL(/studio\.youtube\.com/, { timeout: 300000 });
    console.log('\n Successfully reached YouTube Studio! Profile session is permanently saved.');
  } catch (e) {
    console.log('Timed out or window closed. Any completed login steps are persisted in the profile.');
  }
}

loginInteractive().catch(err => {
  console.error('Error during login:', err);
  process.exit(1);
});
