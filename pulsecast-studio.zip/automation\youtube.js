import { createPersistentContext } from './browser.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const screenshotsDir = path.join(__dirname, '..', 'storage', 'screenshots');

if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

export async function uploadVideo({ videoPath, title, description, visibility = 'PUBLIC', headless = false }) {
  if (!fs.existsSync(videoPath)) {
    throw new Error(`Video file not found at: ${videoPath}`);
  }

  const context = await createPersistentContext(headless);
  const page = context.pages().length > 0 ? context.pages()[0] : await context.newPage();

  const timestamp = Date.now();
  const logs = [];
  const log = (msg) => {
    const entry = `[${new Date().toISOString()}] ${msg}`;
    console.log(entry);
    logs.push(entry);
  };

  try {
    log('Navigating to YouTube Studio...');
    await page.goto('https://studio.youtube.com', { waitUntil: 'networkidle', timeout: 60000 });

    // Check if we were redirected to a Google login page
    if (page.url().includes('accounts.google.com')) {
      const loginScreenshot = path.join(screenshotsDir, `login_needed_${timestamp}.png`);
      await page.screenshot({ path: loginScreenshot });
      throw new Error('Google Sign-in page encountered. Please click "Sync Studio Session" to log in first.');
    }

    log('Locating Create button...');
    const createBtn = page.locator('#create-icon, ytcp-button#create-icon, button:has-text("Create")').first();
    await createBtn.waitFor({ state: 'visible', timeout: 30000 });
    await createBtn.click();

    log('Selecting "Upload videos"...');
    const uploadBtn = page.locator('text="Upload videos", #text-item-0, paper-item:has-text("Upload")').first();
    await uploadBtn.waitFor({ state: 'visible', timeout: 15000 });
    await uploadBtn.click();

    // Upload file
    log(`Injecting video asset: ${videoPath}`);
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles(videoPath);

    // Wait for title input
    log('Awaiting video metadata editor...');
    const titleInput = page.locator('#textbox[aria-label*="title" i], ytcp-social-suggestions-textbox[aria-label*="title" i] #textbox, [contenteditable="true"]').first();
    await titleInput.waitFor({ state: 'visible', timeout: 60000 });

    if (title) {
      log(`Setting title: "${title}"`);
      await titleInput.click();
      await page.keyboard.press('Control+A');
      await page.keyboard.press('Backspace');
      await titleInput.fill(title);
    }

    if (description) {
      log('Writing description and hashtags...');
      const descInput = page.locator('#textbox[aria-label*="description" i], ytcp-social-suggestions-textbox[aria-label*="description" i] #textbox').first();
      if (await descInput.isVisible({ timeout: 5000 }).catch(() => false)) {
        await descInput.click();
        await descInput.fill(description);
      }
    }

    // "Not made for kids" option
    log('Setting audience constraints...');
    const notForKids = page.locator('tp-yt-paper-radio-button[name="NOT_MADE_FOR_KIDS"], [name="NOT_MADE_FOR_KIDS"]').first();
    if (await notForKids.isVisible({ timeout: 6000 }).catch(() => false)) {
      await notForKids.click();
    }

    // Step through the wizard
    log('Navigating wizard steps...');
    for (let i = 0; i < 3; i++) {
      const nextBtn = page.locator('#next-button, button:has-text("Next")').first();
      if (await nextBtn.isVisible({ timeout: 6000 }).catch(() => false)) {
        await nextBtn.click();
        await page.waitForTimeout(2500);
      }
    }

    // Visibility
    log(`Applying visibility mode: ${visibility}...`);
    const visKey = visibility.toUpperCase();
    const visRadio = page.locator(`tp-yt-paper-radio-button[name="${visKey}"], [name="${visKey}"]`).first();
    if (await visRadio.isVisible({ timeout: 6000 }).catch(() => false)) {
      await visRadio.click();
    }

    // Capture screenshot before publishing
    const screenshotPath = path.join(screenshotsDir, `upload_${timestamp}.png`);
    await page.screenshot({ path: screenshotPath });

    // Click Save / Publish
    log('Committing publish action...');
    const doneBtn = page.locator('#done-button, button:has-text("Save"), button:has-text("Publish")').first();
    await doneBtn.waitFor({ state: 'visible', timeout: 15000 });
    await doneBtn.click();

    await page.waitForTimeout(6000);
    log('Deployment successfully broadcast to YouTube Studio!');

    return {
      success: true,
      screenshot: screenshotPath,
      logs
    };
  } catch (error) {
    const errorScreenshot = path.join(screenshotsDir, `error_${timestamp}.png`);
    await page.screenshot({ path: errorScreenshot }).catch(() => {});
    log(`Process failure: ${error.message}`);
    return {
      success: false,
      error: error.message,
      screenshot: errorScreenshot,
      logs
    };
  } finally {
    await context.close();
  }
}
