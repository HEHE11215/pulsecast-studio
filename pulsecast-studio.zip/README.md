# PulseCast Studio // Autonomous Social Video Broadcasting & Scheduling

PulseCast is a production-grade multi-platform automated social media video posting and scheduling application with an Apple-style liquid glassmorphism interface.

## ✨ Features
- **Intelligent Video Scheduling**: Set future dates/times with anti-past validation.
- **Autonomous Dispatch (`node-cron`)**: Background engine checks every 30 seconds for due broadcasts.
- **Credit & Billing System**: Persistent user accounts with 5 free starter credits, upgrade modal, and cancel/refund functionality.
- **Authentication**:
  - Direct Email + Password registration & login.
  - Disposable email rejection & 6-digit verification PIN.
  - Official Google OAuth2 authentication.
- **Independent Channel Hub**: Connect YouTube, X, Instagram, and LinkedIn channels independently of user logins.

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Create a `.env` file in the root directory:
```env
PORT=3000
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_REDIRECT_URI=http://localhost:3000/api/auth/google/callback
```

### 3. Run Application
```bash
node server.js
```
Open [http://localhost:3000](http://localhost:3000) in your browser.
