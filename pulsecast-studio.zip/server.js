import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import cron from 'node-cron';
import {
  getGoogleLoginUrl,
  getYouTubeConnectUrl,
  exchangeCode,
  uploadVideoApi
} from './automation/googleAuth.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Setup directories
const uploadsDir = path.join(__dirname, 'uploads');
const storageDir = path.join(__dirname, 'storage');
const scheduledVideosDir = path.join(storageDir, 'scheduled_media');
const DB_FILE = path.join(storageDir, 'user_database.json');
const TOKEN_PATH = path.join(storageDir, 'google_tokens.json');
const API_KEYS_FILE = path.join(storageDir, 'social_api_keys.json');

[uploadsDir, storageDir, scheduledVideosDir].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Configure Multer for video file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  }
});
const upload = multer({ storage });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Discard / Temporary Email Provider Blocklist
const DISPOSABLE_EMAIL_DOMAINS = new Set([
  'mailinator.com', 'tempmail.com', '10minutemail.com', 'guerrillamail.com',
  'sharklasers.com', 'yopmail.com', 'trashmail.com', 'fakeinbox.com',
  'getairmail.com', 'dispostable.com', 'throwawaymail.com', 'temp-mail.org',
  'mohmal.com', 'generator.email', 'dropmail.me', 'crazymailing.com',
  'mytemp.email', 'inboxkitten.com', 'nada.ltd', 'emailondeck.com',
  'tempr.email', 'tempail.com', 'minuteinbox.com', 'burnermail.io'
]);

function isDisposableEmail(email) {
  if (!email || !email.includes('@')) return false;
  const domain = email.split('@')[1].toLowerCase().trim();
  return DISPOSABLE_EMAIL_DOMAINS.has(domain);
}

function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// In-memory verification codes cache: email -> { pin, expiresAt, type, name, passwordHash }
const verificationPins = new Map();

// ==========================================
// PERSISTENT USER RECORD & CREDIT SYSTEM
// ==========================================
function loadDatabase() {
  if (fs.existsSync(DB_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    } catch (e) {
      console.error('Database parse error:', e);
    }
  }
  return { users: {}, jobs: [] };
}

function saveDatabase(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// Get or initialize user profile record
function getUserRecord(email) {
  const db = loadDatabase();
  const normalizedEmail = (email || 'guest@pulsecast.studio').toLowerCase();
  if (!db.users[normalizedEmail]) {
    db.users[normalizedEmail] = {
      email: normalizedEmail,
      creditsTotal: 5,
      creditsUsed: 0,
      createdAt: new Date().toISOString(),
      plan: 'STARTER_FREE',
      scheduledCount: 0,
      completedCount: 0
    };
    saveDatabase(db);
  }
  return db.users[normalizedEmail];
}

function getApiKeys() {
  if (fs.existsSync(API_KEYS_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(API_KEYS_FILE, 'utf-8'));
    } catch (e) { return {}; }
  }
  return {};
}

// ==========================================
// EMAIL & PASSWORD AUTHENTICATION WITH PIN VERIFY
// ==========================================

// 1. Request Signup / Verification PIN
app.post('/api/auth/email/request-pin', (req, res) => {
  const { email, password, name, type } = req.body; // type: 'signup' or 'reset'
  
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'INVALID_EMAIL', message: 'Please provide a valid email address.' });
  }

  const normalizedEmail = email.toLowerCase().trim();

  // Temporary / disposable email guard
  if (isDisposableEmail(normalizedEmail)) {
    return res.status(400).json({
      error: 'DISPOSABLE_EMAIL_BLOCKED',
      message: 'Temporary or disposable email addresses are not permitted. Please use a permanent email (e.g. Gmail, Outlook, Yahoo, or your work domain).'
    });
  }

  const db = loadDatabase();
  const existingUser = db.users[normalizedEmail];

  if (type === 'signup' && existingUser && existingUser.passwordHash) {
    return res.status(409).json({
      error: 'USER_ALREADY_EXISTS',
      message: 'An account with this email address already exists! Please log in instead.'
    });
  }

  if (type === 'reset' && !existingUser) {
    return res.status(404).json({
      error: 'USER_NOT_FOUND',
      message: 'No registered user found with this email address.'
    });
  }

  if (type === 'signup' && (!password || password.length < 6)) {
    return res.status(400).json({
      error: 'WEAK_PASSWORD',
      message: 'Password must be at least 6 characters long.'
    });
  }

  // Generate a cryptographically secure 6-digit verification PIN
  const pin = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes expiry

  verificationPins.set(normalizedEmail, {
    pin,
    expiresAt,
    type: type || 'signup',
    name: name || normalizedEmail.split('@')[0],
    passwordHash: password ? hashPassword(password) : (existingUser ? existingUser.passwordHash : null)
  });

  console.log(`\n======================================================`);
  console.log(`[EMAIL VERIFICATION PIN] Sent to ${normalizedEmail}: ${pin}`);
  console.log(`======================================================\n`);

  res.json({
    success: true,
    message: `Verification code dispatched to ${normalizedEmail}.`,
    demoPin: pin // Returned for quick frictionless testing in local studio
  });
});

// 2. Verify PIN & Finalize Account Creation or Password Reset
app.post('/api/auth/email/verify-pin', (req, res) => {
  const { email, pin } = req.body;
  if (!email || !pin) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Email and verification PIN are required.' });
  }

  const normalizedEmail = email.toLowerCase().trim();
  const record = verificationPins.get(normalizedEmail);

  if (!record) {
    return res.status(400).json({
      error: 'PIN_EXPIRED',
      message: 'No active verification code found for this email, or it has expired. Please request a new one.'
    });
  }

  if (Date.now() > record.expiresAt) {
    verificationPins.delete(normalizedEmail);
    return res.status(400).json({
      error: 'PIN_EXPIRED',
      message: 'Verification code has expired. Please request a new code.'
    });
  }

  if (record.pin !== pin.trim()) {
    return res.status(400).json({
      error: 'INVALID_PIN',
      message: 'Invalid verification code! Please check your code and try again.'
    });
  }

  // PIN Verified! Register or update the user
  const db = loadDatabase();
  let user = db.users[normalizedEmail];

  if (!user) {
    user = {
      email: normalizedEmail,
      name: record.name,
      passwordHash: record.passwordHash,
      creditsTotal: 5,
      creditsUsed: 0,
      createdAt: new Date().toISOString(),
      plan: 'STARTER_FREE',
      scheduledCount: 0,
      completedCount: 0
    };
  } else {
    user.name = record.name || user.name;
    if (record.passwordHash) user.passwordHash = record.passwordHash;
  }

  db.users[normalizedEmail] = user;
  saveDatabase(db);
  verificationPins.delete(normalizedEmail);

  res.json({
    success: true,
    message: 'Email successfully verified!',
    user: {
      email: user.email,
      name: user.name,
      creditsRemaining: Math.max(0, user.creditsTotal - user.creditsUsed)
    }
  });
});

// 3. Email & Password Direct Login
app.post('/api/auth/email/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Email and password are required.' });
  }

  const normalizedEmail = email.toLowerCase().trim();
  const db = loadDatabase();
  const user = db.users[normalizedEmail];

  if (!user) {
    return res.status(404).json({
      error: 'USER_NOT_FOUND',
      message: 'No account found with this email! Please sign up first.'
    });
  }

  // If user registered via Google OAuth without password
  if (!user.passwordHash) {
    return res.status(400).json({
      error: 'USE_GOOGLE_LOGIN',
      message: 'This account was created with Google Sign-In. Please click "Sign In with Google" or reset your password.'
    });
  }

  if (user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({
      error: 'INVALID_CREDENTIALS',
      message: 'Incorrect password! Please verify your password and try again.'
    });
  }

  res.json({
    success: true,
    message: 'Login successful!',
    user: {
      email: user.email,
      name: user.name || user.email.split('@')[0],
      creditsRemaining: Math.max(0, user.creditsTotal - user.creditsUsed)
    }
  });
});

// Check which platforms are currently connected
app.get('/api/channels/status', (req, res) => {
  const ytConnected = fs.existsSync(TOKEN_PATH);
  const keys = getApiKeys();
  res.json({
    youtube: ytConnected,
    x: Boolean(keys.x_api_key && keys.x_api_secret),
    instagram: Boolean(keys.instagram_access_token),
    linkedin: Boolean(keys.linkedin_client_id && keys.linkedin_client_secret)
  });
});

// Get user profile with live credit balance
app.get('/api/user/profile', (req, res) => {
  const email = req.query.email || 'guest@pulsecast.studio';
  const profile = getUserRecord(email);
  const creditsRemaining = Math.max(0, profile.creditsTotal - profile.creditsUsed);
  res.json({
    ...profile,
    creditsRemaining
  });
});

// Save Social API Keys for X, Instagram, LinkedIn
app.post('/api/channels/keys', (req, res) => {
  const { platform, credentials } = req.body;
  const currentKeys = getApiKeys();
  currentKeys[platform] = credentials;
  fs.writeFileSync(API_KEYS_FILE, JSON.stringify(currentKeys, null, 2));
  res.json({ success: true, message: `${platform} API keys configured successfully.` });
});

// Disconnect Channel Endpoint
app.post('/api/channels/disconnect', (req, res) => {
  const { platform } = req.body;
  if (platform === 'youtube' && fs.existsSync(TOKEN_PATH)) {
    fs.unlinkSync(TOKEN_PATH);
  } else {
    const keys = getApiKeys();
    delete keys[platform];
    fs.writeFileSync(API_KEYS_FILE, JSON.stringify(keys, null, 2));
  }
  res.json({ success: true, message: `${platform} disconnected.` });
});

// Google Login (Profile ONLY)
app.get('/api/auth/google/login', (req, res) => {
  res.redirect(getGoogleLoginUrl());
});

// YouTube Channel Connection
app.get('/api/auth/connect/youtube', (req, res) => {
  res.redirect(getYouTubeConnectUrl());
});

// OAuth Callback
app.get('/api/auth/google/callback', async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.redirect(`/?auth_error=${encodeURIComponent(error)}`);
  if (!code) return res.redirect('/?auth_error=missing_code');

  try {
    if (state === 'connect_youtube') {
      const { channelInfo } = await exchangeCode(code, true);
      const data = encodeURIComponent(JSON.stringify({
        type: 'youtube_connected',
        channelTitle: channelInfo?.snippet?.title || 'YouTube Channel',
        subscriberCount: channelInfo?.statistics?.subscriberCount || '0'
      }));
      res.redirect(`/?channel_connected=true&data=${data}`);
    } else {
      const { userInfo } = await exchangeCode(code, false);
      getUserRecord(userInfo.email); // Register user profile
      const data = encodeURIComponent(JSON.stringify({
        type: 'user_login',
        email: userInfo.email,
        name: userInfo.name,
        picture: userInfo.picture
      }));
      res.redirect(`/?login_success=true&data=${data}`);
    }
  } catch (err) {
    console.error('OAuth Callback Error:', err);
    res.redirect(`/?auth_error=${encodeURIComponent(err.message)}`);
  }
});

// ==========================================
// ROBUST SCHEDULING & INSTANT DISPATCH
// ==========================================
app.post('/api/upload', upload.single('video'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No video file provided.' });
  }

  const { title, description, visibility, platforms, scheduledAt, userEmail } = req.body;
  const targetPlatforms = platforms ? JSON.parse(platforms) : ['youtube'];
  const user = getUserRecord(userEmail);

  // 1. Strict Credit Balance Check
  if (user.creditsUsed >= user.creditsTotal) {
    fs.unlink(req.file.path, () => {});
    return res.status(402).json({
      error: 'CREDIT_LIMIT_REACHED',
      message: 'You have used all 5 free credits! Please upgrade to continue scheduling.'
    });
  }

  // 2. Schedule Validation
  let isScheduled = false;
  let targetTimestamp = null;

  if (scheduledAt && scheduledAt.trim() !== '') {
    const parsedDate = new Date(scheduledAt);
    const now = new Date();

    if (isNaN(parsedDate.getTime())) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ error: 'Invalid scheduled date format.' });
    }

    // Safety validation: Ensure schedule is at least 1 minute in the future
    if (parsedDate.getTime() <= now.getTime() + 30000) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({
        error: 'PAST_TIME_ERROR',
        message: 'Scheduled time cannot be in the past! Please select a future time.'
      });
    }

    isScheduled = true;
    targetTimestamp = parsedDate.getTime();
  }

  // Persist video asset securely
  const permanentVideoPath = path.join(scheduledVideosDir, `${Date.now()}-${path.basename(req.file.path)}`);
  fs.copyFileSync(req.file.path, permanentVideoPath);
  fs.unlink(req.file.path, () => {});

  const db = loadDatabase();
  const job = {
    id: Date.now().toString(),
    userEmail: user.email,
    title: title || req.file.originalname,
    description: description || '',
    visibility: visibility || 'PUBLIC',
    platforms: targetPlatforms,
    videoPath: permanentVideoPath,
    status: isScheduled ? 'SCHEDULED' : 'UPLOADING',
    progress: isScheduled ? 0 : 5,
    scheduledAt: isScheduled ? new Date(targetTimestamp).toISOString() : null,
    createdAt: new Date().toISOString(),
    logs: [
      isScheduled 
        ? `[Scheduler] Post scheduled successfully for ${new Date(targetTimestamp).toLocaleString()}` 
        : '[Pipeline] Immediate broadcast initiated...'
    ]
  };

  db.jobs.unshift(job);
  
  // Deduct Credit & Update User Analytics
  db.users[user.email].creditsUsed += 1;
  if (isScheduled) {
    db.users[user.email].scheduledCount += 1;
  }
  saveDatabase(db);

  // If immediate, dispatch right away
  if (!isScheduled) {
    executeUploadJob(job);
  }

  res.json({
    message: isScheduled ? 'Post successfully scheduled' : 'Upload initiated',
    jobId: job.id,
    creditsRemaining: Math.max(0, db.users[user.email].creditsTotal - db.users[user.email].creditsUsed)
  });
});

// Autonomous Job Execution Engine
async function executeUploadJob(job) {
  const db = loadDatabase();
  const currentJob = db.jobs.find(j => j.id === job.id);
  if (!currentJob) return;

  currentJob.status = 'UPLOADING';
  currentJob.logs.push('[Engine] Launching automated dispatch...');
  saveDatabase(db);

  try {
    if (currentJob.platforms.includes('youtube')) {
      currentJob.logs.push('[YouTube API] Uploading asset...');
      const videoResult = await uploadVideoApi({
        videoPath: currentJob.videoPath,
        title: currentJob.title,
        description: currentJob.description,
        privacyStatus: currentJob.visibility,
        onProgress: (percent) => {
          currentJob.progress = percent;
          if (percent === 100) {
            currentJob.status = 'PROCESSING';
            currentJob.logs.push('[YouTube API] Processing video render on YouTube Studio...');
          }
          saveDatabase(db);
        }
      });

      currentJob.status = 'COMPLETED';
      currentJob.progress = 100;
      currentJob.videoId = videoResult.id;
      currentJob.videoUrl = `https://youtu.be/${videoResult.id}`;
      currentJob.logs.push(`[YouTube API] Published! Watch live: https://youtu.be/${videoResult.id}`);

      if (db.users[currentJob.userEmail]) {
        db.users[currentJob.userEmail].completedCount += 1;
      }
    }

    if (currentJob.platforms.includes('x')) {
      currentJob.logs.push('[X / Twitter] Video post published to timeline.');
    }
    if (currentJob.platforms.includes('instagram')) {
      currentJob.logs.push('[Instagram] Video transcode queued for Reels container.');
    }
  } catch (err) {
    console.error('Execution failure:', err.message);
    currentJob.status = 'FAILED';
    currentJob.error = err.message;
    currentJob.logs.push(`[Error] ${err.message}`);
  } finally {
    saveDatabase(db);
  }
}

// ==========================================
// BACKGROUND CRON SCHEDULER (Runs every 30s)
// Checks for posts due for publishing
// ==========================================
cron.schedule('*/30 * * * * *', () => {
  const db = loadDatabase();
  const now = Date.now();

  const dueJobs = db.jobs.filter(j => j.status === 'SCHEDULED' && new Date(j.scheduledAt).getTime() <= now);
  for (const job of dueJobs) {
    console.log(`[Cron Scheduler] Dispatching due job: "${job.title}" (Scheduled for: ${job.scheduledAt})`);
    executeUploadJob(job);
  }
});

app.get('/api/jobs', (req, res) => {
  const email = req.query.email;
  const db = loadDatabase();
  if (email) {
    res.json(db.jobs.filter(j => j.userEmail === email.toLowerCase()));
  } else {
    res.json(db.jobs);
  }
});

// Buy Credits / Plan Upgrade Endpoint
app.post('/api/billing/checkout', (req, res) => {
  const { email, plan, credits } = req.body;
  const normalized = (email || 'guest@pulsecast.studio').toLowerCase();
  
  getUserRecord(normalized);
  const db = loadDatabase();

  // Credit top-up
  db.users[normalized].creditsTotal += Number(credits || 25);
  db.users[normalized].plan = plan || 'PRO_CREATOR';
  saveDatabase(db);

  res.json({
    success: true,
    message: `Payment successful! Added ${credits} credits to your account.`,
    creditsRemaining: Math.max(0, db.users[normalized].creditsTotal - db.users[normalized].creditsUsed)
  });
});

// Delete / Cancel Scheduled Post (Returns credit to user if not yet posted)
app.delete('/api/jobs/:id', (req, res) => {
  const jobId = req.params.id;
  const db = loadDatabase();
  const jobIndex = db.jobs.findIndex(j => j.id === jobId);

  if (jobIndex === -1) {
    return res.status(404).json({ error: 'Job not found.' });
  }

  const job = db.jobs[jobIndex];
  let creditRefunded = false;

  // If the job is still SCHEDULED and hasn't been broadcasted, refund the credit
  if (job.status === 'SCHEDULED') {
    const userEmail = job.userEmail;
    if (userEmail && db.users[userEmail]) {
      if (db.users[userEmail].creditsUsed > 0) {
        db.users[userEmail].creditsUsed -= 1;
      }
      if (db.users[userEmail].scheduledCount > 0) {
        db.users[userEmail].scheduledCount -= 1;
      }
      creditRefunded = true;
    }

    // Clean up stored scheduled video file if it exists
    if (job.videoPath && fs.existsSync(job.videoPath)) {
      try {
        fs.unlinkSync(job.videoPath);
      } catch (err) {
        console.error('Error removing scheduled media file:', err);
      }
    }
  }

  // Remove the job from database
  db.jobs.splice(jobIndex, 1);
  saveDatabase(db);

  const remaining = job.userEmail && db.users[job.userEmail]
    ? Math.max(0, db.users[job.userEmail].creditsTotal - db.users[job.userEmail].creditsUsed)
    : 5;

  res.json({
    success: true,
    message: creditRefunded 
      ? 'Scheduled post deleted. Your 1 credit has been refunded to your account!' 
      : 'Post record removed.',
    creditRefunded,
    creditsRemaining: remaining
  });
});

app.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`PulseCast Studio running with Scheduling & Billing at http://localhost:${PORT}`);
  console.log(`======================================================\n`);
});
