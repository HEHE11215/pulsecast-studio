import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TOKEN_PATH = path.join(__dirname, '..', 'storage', 'google_tokens.json');

const CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'http://localhost:3000/api/auth/google/callback';

export function createOAuthClient() {
  return new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
}

// 1. Basic User Login (Profile and email ONLY)
export const LOGIN_SCOPES = [
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/userinfo.email'
];

// 2. YouTube Channel Connection (Upload and manage)
export const YOUTUBE_SCOPES = [
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/youtube.readonly'
];

export function getGoogleLoginUrl() {
  const client = createOAuthClient();
  return client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: LOGIN_SCOPES,
    state: 'login'
  });
}

export function getYouTubeConnectUrl() {
  const client = createOAuthClient();
  return client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: YOUTUBE_SCOPES,
    state: 'connect_youtube'
  });
}

export async function exchangeCode(code, isYouTube = false) {
  const client = createOAuthClient();
  const { tokens } = await client.getToken(code);
  client.setCredentials(tokens);

  if (isYouTube) {
    const storageDir = path.dirname(TOKEN_PATH);
    if (!fs.existsSync(storageDir)) fs.mkdirSync(storageDir, { recursive: true });
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(tokens, null, 2));

    let channelInfo = null;
    try {
      const yt = google.youtube({ version: 'v3', auth: client });
      const resp = await yt.channels.list({ part: ['snippet,statistics'], mine: true });
      if (resp.data.items && resp.data.items.length > 0) {
        channelInfo = resp.data.items[0];
      }
    } catch (e) {
      console.error('Channel list error:', e.message);
    }
    return { tokens, channelInfo };
  } else {
    const oauth2 = google.oauth2({ auth: client, version: 'v2' });
    const { data: userInfo } = await oauth2.userinfo.get();
    return { userInfo };
  }
}

export async function getAuthenticatedYouTubeClient() {
  if (!fs.existsSync(TOKEN_PATH)) {
    throw new Error('No YouTube channel connected. Please connect your YouTube channel first.');
  }

  const tokens = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf-8'));
  const client = createOAuthClient();
  client.setCredentials(tokens);

  client.on('tokens', (newTokens) => {
    const updated = { ...tokens, ...newTokens };
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(updated, null, 2));
  });

  return google.youtube({ version: 'v3', auth: client });
}

/**
 * Upload video with 0-100% progress callback
 */
export async function uploadVideoApi({ videoPath, title, description, tags = [], privacyStatus = 'public', onProgress }) {
  const youtube = await getAuthenticatedYouTubeClient();
  const fileSize = fs.statSync(videoPath).size;

  const res = await youtube.videos.insert(
    {
      part: ['snippet,status'],
      requestBody: {
        snippet: {
          title,
          description,
          tags,
          categoryId: '28'
        },
        status: {
          privacyStatus: privacyStatus.toLowerCase()
        }
      },
      media: {
        body: fs.createReadStream(videoPath)
      }
    },
    {
      onUploadProgress: (evt) => {
        const percent = Math.min(100, Math.round((evt.bytesRead / fileSize) * 100));
        if (onProgress) onProgress(percent, evt.bytesRead, fileSize);
      }
    }
  );

  return res.data;
}
